from funcoes import time
from datetime import datetime
hora_agora=datetime.now()
hora_atual=hora_agora.strftime("%H:%M:%S")
print (hora_atual)
from funcao_time import tempo
aberto = 0
valor_acomulado=0
lista_menus=[
"""
-----------------------------------
|          BEM-VINDO              |
|        Menu Principal           |
|                                 |
|     1. Estacionar               |
|     2. Sair                     |
|     3. Administrador            |
|                                 |
|                                 |
|                                 |
-----------------------------------
"""
,
"""
-----------------------------------
|                                 |
|        Menu Estacionar          |
|                                 |
|   1. Escolher andar             |
|   0. Voltar                     |
|                                 |
|                                 |
-----------------------------------

"""
,
"""
-----------------------------------
|                                 |
|       Menu Administrador        |
|                                 |
|    1. Ver andares               |
|    2. Valor acomulado           |
|    3. Inicar/Parar              |
|    0. Voltar                    |
|                                 |
|                                 |
|                                 |     
|                                 |
-----------------------------------
"""
,
"""
-----------------------------------
|                                 |
|            Menu Andares         |
|                                 |
|  Andar 1:U U U U U U U U U U    |
|          U U U U U U U U U U    |
|  Andar 2:U U U U U U U U U U    |
|                                 |
|    0. Voltar                    |
-----------------------------------
"""
,
"""
-----------------------------------
|                                 |
|        Menu Sair                |
|                                 |
|     1. Ecolher andar e lugar    |
|     0. voltar                   |
|                                 |
|                                 |
|                                 |
-----------------------------------
"""
,
"""
-----------------------------------
|                                 |
|        Menu Escolha Andar       |
|                                 |
|     1. Andar 1                  |
|     2. Andar 2                  |
|     0. Voltar                   |
|                                 |
|                                 |
-----------------------------------

"""
,
"""
-----------------------------------
|                                 |
|        Menu Escolha Lugar       |
|              Andar 1            |
|       U U U U U U U U U U       |
|       U U U U U U U U U U       |
|                                 |
|       1-20. Escolha o Lugar     |
|       0. voltar                 |
|                                 |
-----------------------------------
"""
,
"""
-----------------------------------
|                                 |
|        Menu Escolha Lugar       |
|              Andar 2            |
|        U U U U U U U U U U      |
|                                 |
|       1-10. Escolha o Lugar     |
|       0. voltar                 |
|                                 |
-----------------------------------
"""
,
"""
-----------------------------------
|                                 |
|        Menu Pagar               |
|                                 |
| Tem que pagar: U €           |
|                                 |
|                                 |
|     0. voltar                   |
|                                 |
-----------------------------------
"""

]
ocupacao_andar_1=[["_",0]]*20 #Enumeraçao de cada lugar andar 1.Podendo ser disponivel (_) ou indisponivel(U)

ocupacao_andar_2=[["_",0]]*10 # Enumeraçao de cada lugar andar 2.Podendo ser disponivel (_) ou indisponivel(U)

menu_a_mostrar=0
dicionario_historico={}

while True:
    if menu_a_mostrar != 6 and menu_a_mostrar != 7 and menu_a_mostrar!=3 and menu_a_mostrar!=8:
        print(lista_menus[menu_a_mostrar])
        opcao_escolhida=eval(input("Indique a opção desejada: "))
    if menu_a_mostrar==0:  #Menu Principal
        if opcao_escolhida==1:  #Menu Principal-->Menu Estacionar
            menu_a_mostrar=1  #Vai para o menu estacionar
        elif opcao_escolhida==2: #Menu Principal --> Menu Saida
            menu_a_mostrar=4  #Vai para o menu saida
        elif opcao_escolhida==3: #Vai para o menu Administrador 
            palavra_passe=1234 # palabra passe do administrador
            palavra_passe_1=eval(input("Introduza a palabra passe: "))
            if palavra_passe_1==palavra_passe: # palavra passe correta 
                menu_a_mostrar=2
            else:
                menu_a_mostrar=0 # palavra passe incorreta
                print("Usuario negado!")
        else:
            print("Opção Invalida")

    elif menu_a_mostrar==1:    #Menu Estacionar
        if opcao_escolhida==0:  
            menu_a_mostrar=0    #Volta para o menu Principal
        elif opcao_escolhida==1:
            if aberto == 1:
                menu_a_mostrar=5 # Vai para o menu escolha andar
            else:
                print("O parque está fechado")
                menu_a_mostrar=0
        else:
            print("Opção Invalida")
    
    elif menu_a_mostrar==2: #Menu administrador
        if opcao_escolhida==0:
            menu_a_mostrar=0 #Volta para menu principal
        elif opcao_escolhida==1:
            menu_a_mostrar=3 #Menu andares admin
            control_lugares = 0  # Trocar se o lugar esta ocupado o vazio no menu admin 
            
            for i in range (0, len (lista_menus[menu_a_mostrar]),1):
                if lista_menus[menu_a_mostrar][i]== "U" and control_lugares < 20:       
                    print(ocupacao_andar_1 [control_lugares][0], end="", flush= True)
                    control_lugares +=1
                        
                elif lista_menus[menu_a_mostrar][i]== "U" and  control_lugares < 30: 
                    print(ocupacao_andar_2[control_lugares - 20][0], end="", flush= True)
                    control_lugares +=1                         
                
                else:
                    print(lista_menus[menu_a_mostrar][i], end="", flush= True)
                    
                    
        
        elif opcao_escolhida==2:
            print("Valor Acomulado: ",valor_acomulado,"€")
            
        
        elif opcao_escolhida==3:
            if aberto == 0:
                aberto +=1
            else:
                aberto -= 1
        elif opcao_escolhida==0:
            menu_a_mostrar=0
        elif opcao_escolhida == -1: #opcao secreta para apresentar o diccionario historico
            print("Fim do dia")
            print("Historico dos clientes")
            historico(dicionario_historico) # chama a funcão ordena
            control=1 #  leva o control dos cliente
            while control <= len (dicionario_historico):
                print (dicionario_historico[control]) #imprime o historico
                control += 1 # suma um ao control dos clientes
            break #quebra o ciclo            
        
        else:
            print("Opção Invalida")
        
    
    elif menu_a_mostrar==3: #Menu andar admin
        opcao_escolhida=eval(input("Indique a opção desejada: "))
        if opcao_escolhida==0:
            menu_a_mostrar=2 #Volta ao menu admin
        elif opcao_escolhida!=0:
            print("Opção Invalida")
            
            
    elif menu_a_mostrar==4: #Menu Saida
        if opcao_escolhida==0:
            menu_a_mostrar=0 # Volta para o menu principal  
        elif opcao_escolhida==1:
            andar=eval(input("Indique o andar onde deixou o carro: "))
            while True:
                if andar < 1 or andar > 2:
                    print("Andar Inexistente")
                    andar=eval(input("Indique o andar onde deixou o carro: "))
                else:
                    break
                
            lugar=eval(input("Indique o lugar onde deixou o carro: "))
            hora_agora=datetime.now()
            hora_saida=hora_agora.strftime("%H:%M:%S")
            if andar==1:
                while True:
                    if lugar >= 1 and lugar <= 20:
                        print("Lugar aceite!")
                        break
                    else:
                        print("Lugar não aceite!")
                    ocupacao_andar_1[opcao_escolhida-1]= ["_", time()]
           
            elif andar == 2:
                while True:
                    if lugar >= 1 and lugar <= 10:
                        print("Lugar aceite!") 
                        break
                    else:
                        print("Lugar não aceite!")
                    
            menu_a_mostrar=8
                    
        else:
            print("Opção Invalida")
            
    elif menu_a_mostrar==5: #Menu escolha andar
        if opcao_escolhida==1:
            andar_escolhido=1
            menu_a_mostrar=6 #Menu escolha lugar andar 1
            
        elif opcao_escolhida==2:
            andar_escolhido=2
            menu_a_mostrar=7 #Menu escolha lugar andar 2
            
        elif opcao_escolhida==0:
            menu_a_mostrar=1 #Menu estacionar
        else:
            print("Opção Invalida")
        
    elif menu_a_mostrar==6: #Menu escolha lugar andar 1
        if opcao_escolhida==0:
            menu_a_mostrar=5 #Volta a menu escolha andar
            
        if opcao_escolhida==1:
            control_lugares = 0
            for i in range (0, len (lista_menus[menu_a_mostrar]),1):
                if lista_menus[menu_a_mostrar][i]== "U" and control_lugares < 20:       
                    print(ocupacao_andar_1[control_lugares][0], end="", flush= True)
                    control_lugares +=1
                else:
                    print(lista_menus[menu_a_mostrar][i], end="", flush= True)  
            opcao_escolhida=eval(input("\n \n Indique o lugar desejado: "))
            
        if opcao_escolhida >=1 and opcao_escolhida <=20: #Muda de "" a X andar 1
            ocupacao_andar_1[opcao_escolhida-1]= ["X", time()]
            menu_a_mostrar=0
            hora_agora=datetime.now()
            hora_chegada=hora_agora.strftime("%H:%M:%S")
                        
     
        if andar_escolhido==1: #Caso o carro e retirado do andar 1
            for chave in dicionario_historico:
                if chaves == ocupacao_andar_1[lugar][2]: #verifica de o numero do cliente e igual ao atribuido
                    hora_saida=datetime.now() #hora de saida
                    hora_saida_editada =hora_saida.strftime ("%H:%M:%S") #hora de saida editada
                    dicionario_historico[chaves] += [hora_saida_editada, round (valor_a_pagar,2)] #adiciona ao historico a hora de saida e valor a pagar
                    break
                
                
        
    elif menu_a_mostrar==7: #Menu escolha lugar andar 2
        if opcao_escolhida==0:
            menu_a_mostrar=5 #Volta a menu escolha andar
            
        if opcao_escolhida==2:
            control_lugares_2 = 0
            for i in range (0, len(lista_menus[menu_a_mostrar]),1):
                if lista_menus[menu_a_mostrar][i]== "U" and control_lugares_2 < 10:       
                    print(ocupacao_andar_2[control_lugares_2][0], end="", flush= True)
                    control_lugares_2 +=1
                else:
                    print(lista_menus[menu_a_mostrar][i], end="", flush= True)  
            opcao_escolhida=eval(input("\n \n Indique o lugar desejado: "))
            
        if opcao_escolhida >= 1 and opcao_escolhida <= 10: #Muda de "" a X andar 23
            ocupacao_andar_2[opcao_escolhida-1]= ["X", time()]
            menu_a_mostrar=0 
            hora_agora=datetime.now()
            hora_chegada=hora_agora.strftime("%H:%M:%S")
            
        if andar_escolhido==2: #Caso o carro e retirado do andar 1
            for chave in dicionario_historico:
                if chaves == ocupacao_andar_1[lugar-1][2]: #verifica de o numero do cliente e igual ao atribuido
                    hora_saida=datetime.now() #hora de saida
                    hora_saida_editada =hora_saida.strftime ("%H:%M:%S") #hora de saida editada
                    dicionario_historico[chaves] += [hora_saida_editada, round (valor_a_pagar,2)] #adiciona ao historico a hora de saida e valor a pagar
                break
            
                
    elif menu_a_mostrar==8: #Menu a pagar
        if andar_escolhido == 1: # Caso o andar onde o carro estava seja o 1
            tempo= time() - ocupacao_andar_1[lugar-1][1] #Calcula o tempo que o utilizador esteve no andar 1
            valor_a_pagar= 0.02 * tempo # Calcula o valor a pagar para o andar 1
            valor_a_pagar = round (valor_a_pagar,2)
            for i in range (0, len(lista_menus[menu_a_mostrar]),1):
                if lista_menus[menu_a_mostrar][i]== "U":      
                    print(valor_a_pagar,flush= True, end="")
                else:
                    print(lista_menus[menu_a_mostrar][i], flush= True, end="")        
            valor_pago=0
            while valor_pago < valor_a_pagar:
                print("Falta pagar: ",round((valor_a_pagar-valor_pago),2),"€")
                moeda=eval(input("Qual moeda vai introduzir: "))
                valor_pago+=moeda
            troco=valor_pago-valor_a_pagar
            troco=round(troco,2)
            print ("Seu troco foi: ", troco,"€")
            print ("----------------------")
            print ("Talão")
            print ("Andar: ",andar)
            print ("Lugar: ",lugar)
            print ("Hora de entrada: ",hora_chegada)
            print ("Hora de saida: ",hora_saida) 
            print ("Voce pagou: ",valor_a_pagar,"€")
            print ("----------------------")
            ocupacao_andar_1[opcao_escolhida-1]= ["_"]
            menu_a_mostrar=0
            valor_acomulado+=valor_a_pagar            
            
        
        elif andar_escolhido==2: #Caso o andar onde o carro estava seja o 2
            tempo= time() - ocupacao_andar_2[lugar-1][1] #Calcula o tempo que o utilizador esteve no andar 1
            valor_a_pagar = 0.01* tempo # Calcula o valor a pagar para o andar 1
            valor_a_pagar = round (valor_a_pagar,2)
            for i in range (0, len(lista_menus[menu_a_mostrar]),1):
                if lista_menus[menu_a_mostrar][i]== "U":      
                    print(valor_a_pagar,flush= True, end="")
                else:
                    print(lista_menus[menu_a_mostrar][i], flush= True, end="")        
            valor_pago=0
            while valor_pago < valor_a_pagar:
                print("Falta pagar: ",round((valor_a_pagar-valor_pago),2),"€")
                moeda=eval(input("Qual moeda vai introduzir: "))
                valor_pago+=moeda
            troco=valor_pago-valor_a_pagar
            troco=round(troco,2)
            print ("Seu troco foi: ", troco,"€")
            print ("----------------------")
            print ("Talão")
            print ("Andar: ",andar)
            print ("Lugar: ",lugar)
            print ("Hora de entrada: ",hora_chegada)
            print ("Hora de saida: ",hora_saida) 
            print ("Voce pagou: ",valor_a_pagar,"€")
            print ("----------------------")
            ocupacao_andar_1[opcao_escolhida-1]= ["_"]
            menu_a_mostrar=0
            valor_acomulado+=valor_a_pagar            
                
        
        
                