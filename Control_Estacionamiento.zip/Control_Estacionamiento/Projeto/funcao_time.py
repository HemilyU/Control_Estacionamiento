def tempo ():
    import time
    start = time.time()